<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h2><?php echo e($party->p_name); ?></h2>
                        </div>
                        <div class="card-body">
                            <table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Sn.</th>
                                        <th>Date</th>
                                        <th>Remarks</th>
                                        <th>Credit</th>
                                        <th>Debit</th>
                                        <th>Dues</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="transactions-list">
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($transaction->tnx_date); ?></td>
                                        <td><?php echo e($transaction->tnx_remark); ?></td>
                                        <td>
                                            <?php if($transaction->tnx_type == 1): ?>
                                                <?php echo e($transaction->tnx_amount); ?>

                                            <?php else: ?>
                                                0
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($transaction->tnx_type == 1): ?>
                                                0
                                            <?php else: ?>
                                                <?php echo e($transaction->tnx_amount); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($transaction->tnx_final_dues); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-success edit-btn" data="<?php echo e($transaction->tnx_id); ?>">
                                                <i class="fa-regular fa-pen-to-square"></i>
                                            </button>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger delete-btn" data="<?php echo e($transaction->tnx_id); ?>">
                                                <i class="fa-regular fa-trash-can"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH /opt/lampp/htdocs/billing-new/resources/views/party-transaction-view.blade.php ENDPATH**/ ?>