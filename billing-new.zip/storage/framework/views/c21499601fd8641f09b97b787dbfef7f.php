<?php $__env->startSection('title', 'Purchase Entry'); ?>;
<?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h2><?php echo e($account->ac_name); ?></h2>
                        </div>
                        <div class="card-body">
                            <table id="example" class="table table-bordered dt-responsive nowrap table-striped align-middle" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Sn.</th>
                                        <th>Date</th>
                                        <th>Remarks</th>
                                        <th>Credit</th>
                                        <th>Debit</th>
                                        <th>Balance</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody id="account-list">
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td>
                                            <?php if(array_key_exists('t_date', $transaction)): ?>
                                            <?php echo e($transaction['t_date']); ?>

                                            <?php elseif(array_key_exists('tnx_date', $transaction)): ?>
                                            <?php echo e($transaction['tnx_date']); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(array_key_exists('tnx_remark', $transaction)): ?>
                                                <?php if(array_key_exists('p_name',$transaction)): ?>
                                                    <?php echo e($transaction['p_name']); ?>, <?php echo e($transaction['tnx_remark']); ?>

                                                <?php elseif(array_key_exists('c_name',$transaction)): ?>
                                                    <?php echo e($transaction['c_name']); ?>, <?php echo e($transaction['tnx_remark']); ?>

                                                <?php endif; ?>
                                            <?php elseif(array_key_exists('t_remarks', $transaction)): ?>
                                            <?php echo e($transaction['t_remarks']); ?>

                                            <?php endif; ?>
                                        </td>
                                        <?php if(array_key_exists('t_type', $transaction)): ?>
                                            <?php if($transaction['t_type'] == 1): ?>
                                            <td><?php echo e($transaction['t_amount']); ?></td>
                                            <td>0</td>
                                            <?php elseif($transaction['t_type'] == 2): ?>
                                            <td>0</td>
                                            <td><?php echo e($transaction['t_amount']); ?></td>
                                            <?php endif; ?>
                                        <?php elseif(array_key_exists('tnx_type', $transaction)): ?>
                                            <?php if($transaction['tnx_type'] == 1): ?>
                                            <td><?php echo e($transaction['tnx_amount']); ?></td>
                                            <td>0</td>
                                            <?php elseif($transaction['tnx_type'] == 2): ?>
                                            <td>0</td>
                                            <td><?php echo e($transaction['tnx_amount']); ?></td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <td>
                                            <?php if(array_key_exists('tnx_closing_ac_bal',$transaction)): ?>
                                            <?php echo e($transaction['tnx_closing_ac_bal']); ?>

                                            <?php elseif(array_key_exists('t_final_amount',$transaction)): ?>
                                            <?php echo e($transaction['t_final_amount']); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            
                                            <button type="button" class="btn btn-success edit-btn" <?php if (array_key_exists('t_id', $transaction)) {
                                                                                                        echo 'id="' . $transaction['t_id'] . '" data-from="1"';
                                                                                                    } elseif (array_key_exists('tnx_id', $transaction)) {
                                                                                                        echo 'id="' . $transaction['tnx_id'] . '" data-from="2"';
                                                                                                    } ?>>
                                                <i class="fa-regular fa-pen-to-square"></i>
                                            </button>
                                            <!-- data-from="1" = transaction table data || data-from="2" = user_transaction table data -->
                                        </td>
                                        <td>
                                            
                                            <button type="button" class="btn btn-danger delete-btn" <?php if (array_key_exists('t_id', $transaction)) {
                                                                                                        echo 'id="' . $transaction['t_id'] . '" data-from="1"';
                                                                                                    } elseif (array_key_exists('tnx_id', $transaction)) {
                                                                                                        echo 'id="' . $transaction['tnx_id'] . '" data-from="2"';
                                                                                                    } ?>>
                                                <i class="fa-regular fa-trash-can"></i>
                                            </button>
                                            <!-- data-from="1" = transaction table data || data-from="2" = user_transaction table data -->
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
</div>
<?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        console.clear();
        $(document).on('click', '.edit-btn', function() {
            let table = $(this).attr('data-from');
            let id = $(this).attr('id');
            // console.log('table: ' + table);
            // console.log('id: ' + id);
        });
        $(document).on('click', '.delete-btn', function() {
            let table = $(this).attr('data-from');
            let id = $(this).attr('id');
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post("<?php echo e(url('delete-transaction-record')); ?>", {
                        table: table,
                        id: id
                    }, function(res) {
                        if (res === true) {
                            location.reload();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: res
                            });
                        }
                    });
                }
            });
            // console.log('table: ' + table);
            // console.log('id: ' + id);
        });
    });
</script><?php /**PATH /opt/lampp/htdocs/billing-new/resources/views/account-view.blade.php ENDPATH**/ ?>